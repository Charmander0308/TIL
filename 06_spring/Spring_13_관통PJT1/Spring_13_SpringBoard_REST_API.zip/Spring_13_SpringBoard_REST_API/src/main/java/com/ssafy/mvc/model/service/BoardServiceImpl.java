package com.ssafy.mvc.model.service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.ssafy.mvc.model.dao.BoardDao;
import com.ssafy.mvc.model.dto.Board;
import com.ssafy.mvc.model.dto.SearchCondition;

@Service
public class BoardServiceImpl implements BoardService {

	private final BoardDao boardDao;
	private final ResourceLoader loader;

	public BoardServiceImpl(BoardDao boardDao, ResourceLoader loader) {
		this.loader = loader;
		this.boardDao = boardDao;
	}

	@Override
	public List<Board> getBoardList() {
		System.out.println("게시글 전체 목록");
		return boardDao.selectAll();
	}

	@Transactional
	@Override
	public Board readBoard(int id) {
		System.out.println("게시글 상세 조회");
		boardDao.updateViewCnt(id);
		return boardDao.selectOne(id);
	}

	@Transactional
	@Override
	public void writeBoard(Board board) {
		System.out.println("게시글 작성");
//		board.setId(9999);
//		boardDao.insertBoard(board);
		boardDao.insertBoard(board);
	}

	@Transactional
	@Override
	public boolean removeBoard(int id) {
		System.out.println("게시글 삭제");
		int result = boardDao.deleteBoard(id);
		return result == 1;
	}

	@Transactional
	@Override
	public void modifyBoard(Board board) {
		System.out.println("게시글 수정");
		boardDao.updateBoard(board);

	}

	@Override
	public Board getBoard(int id) {
		return boardDao.selectOne(id);
	}

	@Override
	public List<Board> search(SearchCondition condition) {
		// 여기서 조립도 가능하다.
//		condition.setWord("%"+condition.getWord()+"%");
		return boardDao.search(condition);
	}

	@Override
	public void fileUpload(MultipartFile file, Board board) {
		boardDao.insertBoard(board);
		
		if (file != null && file.getSize() > 0) {
			// 파일을 저장하겠다.!
			String fileName = file.getOriginalFilename(); // 확장자를 추출하려고 했을떄 어떻게 할지 고민해보세요~~
			String fileId = UUID.randomUUID().toString(); // 확장자는 없어진다.

			board.setFileId(fileId);
			board.setFileName(fileName);
			// 저장
			try {
				Resource resource = loader.getResource("classpath:/static/img");
				file.transferTo(new File(resource.getFile(), fileId));
				//파일이 저장이 된 상태
				boardDao.insertFile(board);
				
			} catch (IllegalStateException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

}
