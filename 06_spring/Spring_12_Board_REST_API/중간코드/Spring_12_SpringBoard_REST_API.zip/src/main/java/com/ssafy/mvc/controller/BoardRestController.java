package com.ssafy.mvc.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.mvc.model.dto.Board;
import com.ssafy.mvc.model.dto.SearchCondition;
import com.ssafy.mvc.model.service.BoardService;

@RestController
@RequestMapping("/api-board")
public class BoardRestController {
	//서비스 의존성 필요해!
	private final BoardService boardService;
	
//	@Autowired
	public BoardRestController(BoardService boardService) {
		this.boardService = boardService;
	}
	
	//게시글 전체 조회
//	@GetMapping("/board")
//	public ResponseEntity<List<Board>> list(){
//		List<Board> list = boardService.getBoardList();
////		return new ResponseEntity<>(list, HttpStatus.OK);
//		return ResponseEntity.ok(list);
//	}
	
	//게시글 검색 조회
	@GetMapping("/board")
	public ResponseEntity<?> list(@ModelAttribute SearchCondition condition){
		System.out.println(condition);
		
		List<Board> list = boardService.search(condition);
		
		return new ResponseEntity<List<Board>>(list, HttpStatus.OK);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
