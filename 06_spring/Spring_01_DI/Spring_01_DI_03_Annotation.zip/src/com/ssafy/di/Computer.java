package com.ssafy.di;

public interface Computer {
	public abstract String getInfo();
}
