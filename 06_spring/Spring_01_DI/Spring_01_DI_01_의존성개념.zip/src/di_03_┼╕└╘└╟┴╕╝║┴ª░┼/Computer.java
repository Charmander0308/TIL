package di_03_타입의존성제거;

public interface Computer {
	public abstract String getInfo();
}
