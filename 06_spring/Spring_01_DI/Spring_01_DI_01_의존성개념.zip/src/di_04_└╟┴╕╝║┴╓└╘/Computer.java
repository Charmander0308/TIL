package di_04_의존성주입;

public interface Computer {
	public abstract String getInfo();
}
