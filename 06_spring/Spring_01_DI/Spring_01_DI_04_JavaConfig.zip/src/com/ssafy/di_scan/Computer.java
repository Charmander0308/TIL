package com.ssafy.di_scan;

public interface Computer {
	public abstract String getInfo();
}
