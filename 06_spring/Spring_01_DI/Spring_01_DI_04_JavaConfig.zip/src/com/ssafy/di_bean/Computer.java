package com.ssafy.di_bean;

public interface Computer {
	public abstract String getInfo();
}
